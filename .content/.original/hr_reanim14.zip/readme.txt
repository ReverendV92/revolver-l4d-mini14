To install, double click, or place the .vpks in [YourSteamFolder]/steamapps/common/left4dead2/left 4 dead 2/addons/. You must have Left 4 Dead 2 Add-on Support installed (Steam->Library->Tools->Left 4 Dead 2 Add-on Support).
Make sure the one you want is enabled in-game under Main Menu -> Extras -> Add-ons.

Version 1.4 - Tweaked the animations, especially left hand when drawing